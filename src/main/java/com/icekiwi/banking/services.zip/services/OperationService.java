package com.icekiwi.banking.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.icekiwi.banking.models.Operation;
import com.icekiwi.banking.repositories.OperationRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class OperationService {

    private final OperationRepository operationRepository;

    public List<Operation> getOperations() {

        return null;
    }

}
