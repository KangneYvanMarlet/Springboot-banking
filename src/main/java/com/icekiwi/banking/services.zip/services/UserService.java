package com.icekiwi.banking.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.icekiwi.banking.models.User;
import com.icekiwi.banking.repositories.UserRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public List<User> getUsers() {

        return null;

    }

    public User getUserInfo(String Matricule) {
        return null;
    }

}
