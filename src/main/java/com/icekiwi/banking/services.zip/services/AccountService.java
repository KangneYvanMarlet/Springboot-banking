package com.icekiwi.banking.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.icekiwi.banking.models.Account;
import com.icekiwi.banking.models.Operation;
import com.icekiwi.banking.repositories.AccountRepository;
import com.icekiwi.banking.repositories.OperationRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AccountService {

    final private AccountRepository accountRepository;
    final private OperationRepository operationRepository;

    // send money from account to another one
    public void send(String senderId, String recipientId, int value) {

        Account operator = accountRepository.getReferenceById(senderId);
        Account recipient = accountRepository.getReferenceById(recipientId);

        int newOperatorvalue = operator.getValue() - value;
        operator.setValue(newOperatorvalue);
        recipient.setValue(recipient.getValue() + value);

        Operation operation = new Operation();

        operation.setOperator(operator);
        operation.setRecipient(recipient);

        operationRepository.save(operation);
        accountRepository.save(operator);
        accountRepository.save(recipient);

    }

    public void cashOut(String id, int value) {

    }

    public void CashIn(String id, int value) {
        Account operator = accountRepository.getReferenceById(id);
        Operation operation = new Operation();
        operation.setOperator(operator);

        operationRepository.save(operation);
        accountRepository.save(operator);

    }

    public List<Account> listAccounts() {
        return null;
    }

    public void getAccount(String id) {

    }
}
